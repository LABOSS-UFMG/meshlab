# -------------------------------------------------------------------------------- #
import gmsh

from typing import Sequence

from meshlab.data.mesh import Mesh
from meshlab.data.contour import Contour
from meshlab.utils import validation

# -------------------------------------------------------------------------------- #
def export_mesh(
        mesh: Mesh,
        walls: Sequence[Contour],
        fronts: Sequence[Contour],
        farfield: Contour,
        filename: str = "airfoil.msh",
        show: bool = False,
    ) -> None:
    """
    Export a MeshLab mesh to Gmsh.

    Parameters
    ----------
    mesh : Mesh
        Mesh containing the generated boundary-layer elements.
    walls : Sequence[Contour]
        Wall contours. Each contour is exported as a physical group.
    fronts : Sequence[Contour]
        Front contours delimiting the already-generated mesh.
    farfield : Contour
        External contour enclosing the computational domain.
    filename : str, default="airfoil.msh"
        Name of the output Gmsh mesh file.
    show : bool, default=False
        If True, display the Gmsh GUI before saving the mesh file.
    """
    # ------------------------------------------------------------------------ #
    # Validate input arguments
    validation.is_object(mesh, Mesh)

    validation.is_sequence(walls, None, Contour)
    validation.is_sequence(fronts, None, Contour)

    validation.is_object(farfield, Contour)

    # ------------------------------------------------------------------------ #
    # Initialize Gmsh
    gmsh.initialize()

    try:

        # -------------------------------------------------------------------- #
        # Create a new Gmsh model
        gmsh.model.add("MeshLab")

        # -------------------------------------------------------------------- #
        # Future implementation:
        
        # 1. Export mesh vertices.
        # 2. Export quadrilateral boundary-layer cells.
        # 3. Export wall contours.
        # 4. Export front contours.
        # 5. Export farfield contour.
        # 6. Generate the outer mesh.
        # 7. Create physical groups.
        
        # -------------------------------------------------------------------- #

        # Show the model before saving
        if show:
            gmsh.fltk.run()

        # Write mesh file
        gmsh.write(filename)

    finally:

        # -------------------------------------------------------------------- #
        # Finalize Gmsh even if an exception is raised
        gmsh.finalize()

    # ------------------------------------------------------------------------ #
    return None

# -------------------------------------------------------------------------------- #